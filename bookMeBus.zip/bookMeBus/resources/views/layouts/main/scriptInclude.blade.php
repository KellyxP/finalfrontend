<script src="{{asset('/assets/')}}/library/modernizr.custom.97074.js"></script>

    <script src="{{asset('/assets/')}}/library/jquery-1.11.3.min.js"></script>

    <script src="{{asset('/assets/')}}/library/bootstrap/js/bootstrap.js"></script>

    <script type="text/javascript" src="{{asset('/assets/')}}/js/jquery.easing.1.3.js"></script>

    <!-- [ PLUGIN SCRIPT ] -->

    <script src="{{asset('/assets/')}}/library/vegas/vegas.min.js"></script>

    <script src="{{asset('/assets/')}}/js/plugins.js"></script>

    <!-- [ TYPING SCRIPT ] -->

    <script src="{{asset('/assets/')}}/js/typed.js"></script>

    <!-- [ COUNT SCRIPT ] -->

    <script src="{{asset('/assets/')}}/js/fappear.js"></script>

    <script src="{{asset('/assets/')}}/js/jquery.countTo.js"></script>

    <!-- [ SLIDER SCRIPT ] -->

    <script src="{{asset('/assets/')}}/js/owl.carousel.js"></script>

    <script src="{{asset('/assets/')}}/js/jquery.magnific-popup.min.js" type="text/javascript"></script>

    <script type="text/javascript" src="{{asset('/assets/')}}/js/SmoothScroll.js"></script>


    <!-- [ COMMON SCRIPT ] -->
    <script src="{{asset('/assets/')}}/js/common.js"></script>

    {{-- login script --}}

    {{-- <script src="{{asset('/assets/')}}/js/jquery-1.12.4-jquery.min.js"></script> --}}
    
