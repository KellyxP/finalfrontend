<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Online Ticket Reservation System - Passenger's Account </title>
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
    <script src="{{asset('/assets/')}}/js/alpine.js"></script>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="{{asset('/assets/')}}/plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{asset('/assets/')}}/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="{{asset('/assets/')}}/dist/css/style.css">