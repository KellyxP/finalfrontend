<script src="<?php echo e(asset('/assets/')); ?>/library/modernizr.custom.97074.js"></script>

    <script src="<?php echo e(asset('/assets/')); ?>/library/jquery-1.11.3.min.js"></script>

    <script src="<?php echo e(asset('/assets/')); ?>/library/bootstrap/js/bootstrap.js"></script>

    <script type="text/javascript" src="<?php echo e(asset('/assets/')); ?>/js/jquery.easing.1.3.js"></script>

    <!-- [ PLUGIN SCRIPT ] -->

    <script src="<?php echo e(asset('/assets/')); ?>/library/vegas/vegas.min.js"></script>

    <script src="<?php echo e(asset('/assets/')); ?>/js/plugins.js"></script>

    <!-- [ TYPING SCRIPT ] -->

    <script src="<?php echo e(asset('/assets/')); ?>/js/typed.js"></script>

    <!-- [ COUNT SCRIPT ] -->

    <script src="<?php echo e(asset('/assets/')); ?>/js/fappear.js"></script>

    <script src="<?php echo e(asset('/assets/')); ?>/js/jquery.countTo.js"></script>

    <!-- [ SLIDER SCRIPT ] -->

    <script src="<?php echo e(asset('/assets/')); ?>/js/owl.carousel.js"></script>

    <script src="<?php echo e(asset('/assets/')); ?>/js/jquery.magnific-popup.min.js" type="text/javascript"></script>

    <script type="text/javascript" src="<?php echo e(asset('/assets/')); ?>/js/SmoothScroll.js"></script>


    <!-- [ COMMON SCRIPT ] -->
    <script src="<?php echo e(asset('/assets/')); ?>/js/common.js"></script>

    

    
    
<?php /**PATH C:\Users\Mengly\Desktop\Paragon-Learning\year3\web_dev2\Final\bookMeBus\resources\views/layouts/scriptInclude.blade.php ENDPATH**/ ?>