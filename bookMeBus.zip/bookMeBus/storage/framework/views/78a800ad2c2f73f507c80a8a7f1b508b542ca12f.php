<footer class="site-footer section-spacing text-center " id="eight">


    <div class="container">

        <div class="row">

            <div class="col-md-4">

                <p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>

            </div>

            <div class="col-md-4"> <small>&copy; 2022, Developed By Adelabu Oluwatoyin Simbiat </small></div>

            <div class="col-md-4">

                <!--social-->

                <!-- 
    <ul class="social">

      <li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter "></i></a></li>

      <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>

      <li><a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube-play"></i></a></li>

    </ul> -->


                <!--social end-->


            </div>

        </div>

    </div>

</footer><?php /**PATH C:\Users\Mengly\Desktop\Paragon-Learning\year3\semester 5\web_dev2\Final\bookMeBus\resources\views/layouts/main/footer.blade.php ENDPATH**/ ?>